# Veyra AI V0.3 update

This is an incremental update against the retained V0.2 delivery. GitHub repository access returned 404; current remote source was not read. Do not replace your existing project with full-source.

In your existing Codespaces repository terminal, after uploading this ZIP:

```bash
git switch -c feature/v0.3-prompt-engine
unzip -q Veyra_AI_V0.3.zip
python3 veyra-v03-update/apply_update.py --check
python3 veyra-v03-update/apply_update.py --apply
bash start.sh --isolated
```

Apply only if check reports no conflicts. Backups use the existing `.v02-backups/update-*` folder convention. Open port 8000 Private. A fresh environment needs Codespaces: Rebuild Container first; a working V0.2 Codespace can reuse its current browser/devcontainer configuration.

Local generation requires no key or paid service. The optional AI provider is disabled by default. Generate after opening a site/selection, then review, edit, copy or regenerate in the new panel. Full page means visible content only.

165 Python tests and 15 frontend tests passed, plus the production build and HTTP startup smoke. Ten browser tests were skipped because Chromium is unavailable. Docker/Codespaces execution and real-provider AI were not verified; strict acceptance failed at browser startup. This is implemented source, not a claim of completed end-to-end acceptance.

Read [startup and AI configuration](full-source/README.md), [upgrade/conflicts](full-source/UPGRADE.md), [actual results](full-source/TEST_REPORT.md), [file list](full-source/docs/MODIFIED_FILES.md) and [security](full-source/SECURITY.md). Tests require no real AI credentials. Existing V0.2 runtime notes and historical verification limitations are clearly labelled.
