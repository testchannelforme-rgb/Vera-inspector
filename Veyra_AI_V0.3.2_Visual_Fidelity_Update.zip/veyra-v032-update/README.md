# Veyra AI V0.3.2 Visual Fidelity Update

Changed-files upgrade: **32 actual source/documentation/test files**, not a replacement project.

1. Read **[INSTALL.md](INSTALL.md)** before applying. Protect/commit existing work and use `feature/v0.3.2-visual-fidelity`.
2. From the existing repository root, run `python3 veyra-v032-update/apply_update.py --check`.
3. Only after a passing check, run the same command with `--apply`, then `bash start.sh --isolated`. Keep forwarded port 8000 Private.
4. Rollback before later edits: `python3 veyra-v032-update/apply_update.py --rollback latest`.

The guard validates exact touched-file hashes, new-file collisions and six compatibility anchors, refuses tracked edits and unsafe paths, and creates backups. If it stops, preserve your latest source and reconcile the reported files; do not defeat the guard. The private Codespace/checkpoint `29ef127` was inaccessible, so exact installed compatibility is not claimed.

The update improves gradient/background ownership, pseudo decoration, text fill/clip/stroke, layering evidence and structured local prompts. No dependency, UI redesign, paid service, Docker/network/CSP change or required API key.

**Actual verification:** 299 Python passed, 20 browser-dependent skipped; 50 JavaScript/frontend passed; build and HTTP smoke passed. The installed payload was retested and rollback verified. Chromium installation/startup failed here, so public websites, Codespaces, live AI and screenshot comparisons are unverified.

- [Installation and rollback](INSTALL.md)
- [Exact changed-file manifest](CHANGED_FILES.md)
- [Baseline/design/security/limits](BASELINE_AND_DESIGN.md)
- [Technical changelog](CHANGELOG.md)
- [Tests, failures and limitations](TEST_REPORT.md)
- [Actual package installation test](verification/PACKAGE_INSTALL_TEST.md)
- [Manual acceptance checklist](MANUAL_ACCEPTANCE.md)

`updated/` contains complete replacement/new files at their repository-relative paths; `baseline/` contains exact preimages of replaced files. `manifest.json` holds SHA-256 hashes and source provenance. `changes.patch` is for review only; the guarded installer is the primary installation route. `SHA256SUMS.txt` covers package contents except itself. No remote branch/PR/deployment was created; local source commit is recorded in the manifest.
