# Source protection audit

Actual Git preimage byte comparisons passed for these 13 untouched files:

- backend/app/inspect.js
- backend/app/security.py
- backend/app/browser_manager.py
- backend/app/config.py
- backend/app/prompts/boundary.js
- backend/app/prompts/provider.py
- backend/app/prompts/service.py
- backend/app/prompts/schemas.py
- backend/app/prompts/style_groups.py
- backend/tests/test_ui.py
- compose.inspection.yml
- .devcontainer/devcontainer.json
- .devcontainer/Dockerfile

Frontend dependency/devDependency maps remain identical; package version only changed. `main.py` changed only two version strings, leaving CSP and API protection middleware unchanged. No network/sandbox/deployment flag was altered. This audit compares the supplied reconstructed baseline, not unseen Codespace modifications. Those remain guarded rather than overwritten.

Local source branch: feature/v0.3.2-visual-fidelity
Local source commit: 75d5fac6726a25c195732adbf65687c191df20cf
No push, PR, merge or public deployment performed.
