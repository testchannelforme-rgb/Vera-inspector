# Actual package installation test

Executed on 26 October 2026 against a fresh reconstructed V0.3.1 Git repository on `feature/v0.3.2-visual-fidelity` (local, not Codespaces).

- PASS: `apply_update.py --check` verified all 32 payload/preimage hashes and six compatibility anchors without writing.
- PASS: `--apply` installed all 32 files with a backup journal; every installed SHA-256 matches the manifest.
- PASS: simulated committed, unrelated Codespaces changes in `backend/tests/test_ui.py` and `backend/app/config.py` remained byte-identical.
- PASS: after committing installation, repeat `--check` reported zero changes.
- PASS: installed payload Python suite: 299 passed, 20 browser-dependent skips, zero failures.
- PASS: installed payload JavaScript/frontend suite: 50 passed, zero failures; Vite build passed.
- PASS: rollback restored every original payload path byte-for-byte, removed introduced files and retained both unrelated fixes.
- PASS: a second application followed by a later source edit caused rollback refusal; the edit remained intact.
- PASS: a separate checkout with an unknown committed collector change refused installation before any new visual file was written.

An initial harness run tested the API before building the frontend and failed the existing static-route assertion (404). Building first, as required by the documented setup/test workflow, resolved it; the final installed-payload results above are the fresh rerun. No application/CSP change was made to pass that check.

The simulated fixes exercise preservation, not compatibility with the inaccessible real checkpoint `29ef127`. The installer will still stop if your touched files or anchors differ. Browser tests remain skipped because Chromium is absent; no actual Docker/Codespaces install or real-site visual comparison was performed.
