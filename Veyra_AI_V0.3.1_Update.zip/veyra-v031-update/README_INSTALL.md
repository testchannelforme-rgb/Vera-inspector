# Veyra AI V0.3.1 — changed-files update

Built from your attached Veyra_V0.3_Clean_For_Sol.zip. This package changes 30 source/documentation paths and includes a full manifest, baseline comparison copies, updated files with repository-relative paths, a unified patch and a guarded installer. It does not contain an entire replacement application, secrets, browser caches, runtime data, virtual environments or dependencies.

Save/commit current work before installation. In the existing Codespace repository root, upload this ZIP and run:

```bash
git status --short
git switch -c feature/v0.3.1-prompt-accuracy
unzip -q Veyra_AI_V0.3.1_Update.zip
python3 veyra-v031-update/apply_update.py --check
python3 veyra-v031-update/apply_update.py --apply
bash start.sh --isolated
```

If the branch already exists, use `git switch feature/v0.3.1-prompt-accuracy` instead. Apply only if check passes. Dirty tracked source, committed baseline differences, path/symlink issues or checksum failures are refused before source writes. Do not reset or force-copy to bypass conflicts. Keep port 8000 Private. No devcontainer/dependency/browser-stack update is needed for a working V0.3 Codespace.

The installer backs up originals under `.v031-backups/update-*`. To roll back before later edits:

```bash
python3 veyra-v031-update/apply_update.py --rollback latest
bash start.sh --isolated
```

Rollback refuses changes made after installation. Read [complete installation/rollback instructions](updated/UPGRADE.md), [every changed file](updated/docs/MODIFIED_FILES.md), [actual tests and limitations](updated/TEST_REPORT.md), [accuracy design](updated/docs/V031_ACCURACY.md) and [manual real-site acceptance](updated/docs/V031_ACCEPTANCE.md).

214 Python and 34 Node tests pass; Vite build passes. Sixteen browser checks were skipped and strict browser acceptance fails here because protected Chromium is absent. No real-site/Codespaces/live-AI success is claimed. Synthetic DOM rectangles are test fixtures only. Local prompt generation needs no key or paid service. Browser/network/provider/core UI files remain unchanged. See the package verification report for application, regression and rollback results against the attached baseline.
