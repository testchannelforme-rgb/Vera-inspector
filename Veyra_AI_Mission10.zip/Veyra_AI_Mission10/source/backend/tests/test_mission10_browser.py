"""Trusted local-fixture UI checks; not production browser sandbox acceptance."""
import os
import pytest
from playwright.async_api import expect
from test_studio_browser import source_app
from app.studio.local import reconstruct
from test_studio import evidence

pytestmark=pytest.mark.browser


@pytest.mark.parametrize('viewport',[{'width':1440,'height':1000},{'width':390,'height':844}])
async def test_preview_cannot_force_fullscreen_and_explicit_controls_work(fixture_site,monkeypatch,viewport):
    if not os.getenv('STUDIO_TEST_CHROMIUM'):pytest.skip('Trusted fixture UI runner is unavailable.')
    async with source_app(fixture_site,monkeypatch) as (base,manager,service):
        context=await manager.browser.new_context(viewport=viewport)
        if viewport['width']==390:
            await context.add_init_script('Element.prototype.requestFullscreen=undefined')
        page=await context.new_page();await page.goto(base)
        project,_=reconstruct(evidence(),'vanilla')
        project.files['script.js']="""async function force(){try{await document.documentElement.requestFullscreen();document.body.dataset.forced='yes'}catch{document.body.dataset.forced='blocked'}};setTimeout(force,30);document.querySelector('button').addEventListener('click',force);"""
        await page.evaluate('(project)=>localStorage.setItem("veyra.code-studio.v2",JSON.stringify({schema:2,project,original:project,file:"script.js",savedAt:new Date().toISOString(),history:[]}))',project.model_dump())
        await page.goto(base+'/#/inspector')
        studio=page.get_by_role('region',name='Veyra Code Studio')
        mobileTab=studio.get_by_role('tab',name='Live preview',exact=True)
        await expect(studio).to_be_visible()
        if viewport['width']<900:await mobileTab.click()
        iframe=studio.frame_locator('iframe')
        await expect(iframe.locator('body')).to_have_attribute('data-forced','blocked')
        assert await page.evaluate('document.fullscreenElement===null')
        assert await page.locator('.workspace-fullscreen').count()==0
        await iframe.get_by_role('button').click()
        await expect(iframe.locator('body')).to_have_attribute('data-forced','blocked')
        assert await page.evaluate('document.fullscreenElement===null')
        await studio.get_by_role('button',name='Fullscreen preview',exact=True).click()
        await expect(studio.locator('.studio-live')).to_have_class('studio-live workspace-fullscreen')
        await studio.locator('.studio-live').get_by_role('button',name='Exit preview fullscreen',exact=True).click()
        await expect(studio.locator('.studio-live')).to_have_class('studio-live')
        await studio.get_by_role('button',name='Fullscreen editor',exact=True).click()
        await expect(studio.locator('.studio-edit')).to_have_class('studio-edit workspace-fullscreen')
        await page.keyboard.press('Escape')
        await expect(studio.locator('.studio-edit')).to_have_class('studio-edit')
        await expect(page.locator('.site-header')).to_be_visible()
        await context.close()


async def test_delayed_javascript_rendering_inspection_prompt_code_and_preview(fixture_site,monkeypatch):
    if not os.getenv('STUDIO_TEST_CHROMIUM'):pytest.skip('Trusted fixture UI runner is unavailable.')
    import httpx
    async with source_app(fixture_site,monkeypatch) as (base,manager,service):
        async with httpx.AsyncClient(base_url=base,headers={'X-Veyra-Client':'inspector-v0.1'},timeout=30,trust_env=False) as client:
            opened=await client.post('/api/sessions',json={'url':fixture_site+'/dynamic.html','viewport':{'width':1280,'height':800}})
            assert opened.status_code==201,opened.text
            data=opened.json();session=manager.sessions[data['sessionId']]
            target=await session.page.locator('#hydrated').bounding_box()
            assert target and target['width']==200
            selected=await client.post('/api/sessions/'+data['sessionId']+'/select',json={'frameId':data['frame']['frameId'],'x':target['x']+20,'y':target['y']+20})
            assert selected.status_code==200,selected.text
            selection=selected.json()
            body={'sessionId':data['sessionId'],'frameId':selection['frame']['frameId'],'referenceId':selection['inspection']['element']['referenceId']}
            prompt=await client.post('/api/prompts/generate',json=body)
            assert prompt.status_code==200 and '200px' in prompt.json()['prompt'] and 'Inspect hydrated button' in prompt.json()['prompt']
            code=await client.post('/api/studio/generate',json={**body,'format':'react'})
            assert code.status_code==200,code.text
            preview=await client.post('/api/studio/preview',json={'project':code.json()['project']})
            assert preview.status_code==200,preview.text
            rendered=await client.get(preview.json()['url'])
            assert rendered.status_code==200
            assert "sandbox allow-scripts" in rendered.headers['content-security-policy']
            assert 'fullscreen=()' in rendered.headers['permissions-policy']


async def test_account_sign_in_gates_drafts_and_preferences_clear_only_current_scope(fixture_site,monkeypatch):
    if not os.getenv('STUDIO_TEST_CHROMIUM'):pytest.skip('Trusted fixture UI runner is unavailable.')
    import json
    monkeypatch.setenv('VEYRA_USERS_JSON',json.dumps({'alice':{'token':'a'*40,'tier':'premium'},'bob':{'token':'b'*40,'tier':'free'}}))
    async with source_app(fixture_site,monkeypatch) as (base,manager,service):
        context=await manager.browser.new_context(viewport={'width':1440,'height':1000})
        page=await context.new_page();await page.goto(base)
        project,_=reconstruct(evidence(),'vanilla')
        await page.evaluate('''project=>{for(const id of ['alice','bob','operator']){const p=structuredClone(project);p.files['style.css']+='\\n/* '+id+' */';localStorage.setItem('veyra.code-studio.v2'+(id==='operator'?'':'::'+id),JSON.stringify({schema:2,project:p,original:p,file:'style.css',savedAt:new Date().toISOString(),history:[]}));}}''',project.model_dump())
        await page.goto(base+'/#/inspector')
        await expect(page.get_by_label('Access token')).to_be_visible()
        await expect(page.get_by_role('region',name='Veyra Code Studio')).to_have_count(0)
        await page.get_by_label('Access token').fill('a'*40);await page.get_by_role('button',name='Sign in',exact=True).click()
        studio=page.get_by_role('region',name='Veyra Code Studio')
        await expect(studio.get_by_role('textbox',name='Code editor style.css')).to_contain_text('alice')
        await page.get_by_role('button',name='Sign out',exact=True).click()
        await expect(studio).to_have_count(0)
        await page.get_by_label('Access token').fill('b'*40);await page.get_by_role('button',name='Sign in',exact=True).click()
        await expect(studio.get_by_role('textbox',name='Code editor style.css')).to_contain_text('bob')
        await page.goto(base+'/#/preferences')
        await page.get_by_role('button',name='Clear local data…',exact=True).click()
        await page.get_by_role('button',name='Confirm clear local data',exact=True).click()
        assert await page.evaluate("localStorage.getItem('veyra.code-studio.v2::bob')===null")
        assert await page.evaluate("localStorage.getItem('veyra.code-studio.v2::alice')!==null&&localStorage.getItem('veyra.code-studio.v2')!==null")
        await context.close()
