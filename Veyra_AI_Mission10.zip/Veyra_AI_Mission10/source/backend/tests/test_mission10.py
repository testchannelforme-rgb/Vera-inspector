import asyncio
from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace
from datetime import datetime, timezone, timedelta
import importlib.util
import json
from pathlib import Path
from unittest.mock import AsyncMock
import httpx
import pytest
from fastapi.testclient import TestClient
from app.accounts import Account, Accounts, UsageLedger, account_context, ledger_context
from app.browser_manager import BrowserManager, Session, SessionError
from app.config import Settings
from app.main import create_app
from app.prompts.compact import render_compact
from app.prompts.deterministic import render_prompt
from app.prompts.granite import GraniteConfig, GraniteProvider
from app.prompts.provider import CompatibleProvider, ProviderConfig, ProviderFailure
from app.prompts.service import PromptService
from app.studio.provider import named_provider
from app.studio.service import StudioService
from test_prompts import evidence, request, AI_RESULT


def test_compact_fidelity_and_measured_reduction():
    data=evidence()
    data['hover']={'requestedIntervalMs':100,'actualDurationMs':1004,'baselineWasAlreadyHovered':False,
                   'changes':{'transform':{'before':'none','observed':'matrix(1,0,0,1,0,-4)'}},'geometrySamples':[]}
    full,_=render_prompt(data,request())
    compact,_=render_compact(data,request())
    balanced,_=render_compact(data,request(lengthMode='balanced'))
    assert len(compact)<len(full)*.6
    assert len(compact)<len(balanced)<len(full)
    for value in data['nodes'][0]['styles'].values():assert value in compact
    for value in ('1004','matrix(1,0,0,1,0,-4)','parent None','breakpoints','untrusted'):
        assert value in compact
    assert all(f'## {i}.' in compact for i in range(1,9))


async def test_detailed_and_renderer_fallback(monkeypatch):
    service=PromptService(ProviderConfig())
    data=evidence()
    full,_=render_prompt(data,request(lengthMode='detailed'))
    assert (await service.generate(data,request(lengthMode='detailed'))).prompt==full
    def fail(*a):raise ValueError('bounded evidence issue')
    monkeypatch.setattr('app.prompts.service.render_compact',fail)
    result=await service.generate(data,request())
    assert result.prompt==full and any('established detailed' in w for w in result.warnings)


def test_daily_account_persistence_reset_and_inheritance(tmp_path,monkeypatch):
    monkeypatch.setenv('VEYRA_QUOTA_PREMIUM_STANDARD_PROMPTS','1')
    clock=[datetime(2026,10,31,23,59,tzinfo=timezone.utc)]
    path=str(tmp_path/'ledger.db');ledger=UsageLedger(path,lambda:clock[0])
    a,b=Account('a'),Account('b','boss')
    assert ledger.limits['premium']['standard_prompts']==10
    for _ in range(10):ledger.charge('standard_prompts',a)
    with pytest.raises(SessionError):ledger.charge('standard_prompts',a)
    assert UsageLedger(path,lambda:clock[0]).snapshot(a)['features']['standard_prompts']['remaining']==0
    assert ledger.snapshot(b)['features']['standard_prompts']['remaining']==30
    with pytest.raises(SessionError):ledger.charge('gemini_code',a)
    clock[0]+=timedelta(minutes=2)
    assert ledger.snapshot(a)['features']['standard_prompts']['remaining']==10
    assert ledger.snapshot(a)['resetsAt']=='2026-11-02T00:00:00+00:00'


def test_atomic_quota_under_concurrent_workers(tmp_path):
    db=str(tmp_path/'workers.db');ledger=UsageLedger(db)
    def reserve(_):
        worker=UsageLedger(db)
        try:worker.charge('basic_code',Account('student'));return True
        except SessionError:return False
        finally:worker.db.close()
    with ThreadPoolExecutor(max_workers=6) as pool:results=list(pool.map(reserve,range(12)))
    assert sum(results)==2
    assert ledger.snapshot(Account('student'))['features']['basic_code']['used']==2


def test_provider_budget_is_atomic_and_zero_by_default(monkeypatch):
    ledger=UsageLedger(':memory:')
    with pytest.raises(SessionError):ledger.reserve_provider('gemini',100)
    assert not list(ledger.db.execute('SELECT * FROM daily_usage'))
    monkeypatch.setenv('VEYRA_EXTERNAL_REQUESTS_PER_DAY','2')
    monkeypatch.setenv('VEYRA_PROVIDER_GEMINI_REQUESTS_PER_DAY','1')
    monkeypatch.setenv('VEYRA_EXTERNAL_OUTPUT_TOKENS_PER_DAY','200')
    ledger.reserve_provider('gemini',150)
    with pytest.raises(SessionError):ledger.reserve_provider('gemini',40)
    assert dict(ledger.db.execute("SELECT feature,count FROM daily_usage"))['all_requests']==1


def test_account_tokens_and_tiers_cannot_be_client_selected(monkeypatch):
    monkeypatch.setenv('VEYRA_USERS_JSON',json.dumps({'alice':{'token':'a'*40,'tier':'premium'},'bob':{'token':'b'*40,'tier':'free'}}))
    accounts=Accounts()
    assert accounts.authenticate('a'*40)==Account('alice','premium')
    for token in ('','premium','boss','a'*39):
        with pytest.raises(SessionError):accounts.authenticate(token)
    monkeypatch.setenv('VEYRA_USERS_JSON',json.dumps({'alice':{'token':'same'*10},'bob':{'token':'same'*10}}))
    with pytest.raises(ValueError,match='unique'):Accounts()


def test_api_identity_cookie_ownership_and_usage(monkeypatch):
    monkeypatch.setenv('VEYRA_USERS_JSON',json.dumps({'alice':{'token':'a'*40,'tier':'premium'},'bob':{'token':'b'*40,'tier':'boss'}}))
    manager=BrowserManager(Settings());manager.start=AsyncMock();manager.stop=AsyncMock()
    page=AsyncMock();manager.sessions['s']=Session('s',AsyncMock(),page,frame_id='f')
    manager.sessions['s'].owner='alice'
    monkeypatch.setattr('app.main.collect_evidence',AsyncMock(return_value=evidence()))
    service=StudioService(db=':memory:')
    ledger=UsageLedger(':memory:')
    app=create_app(manager=manager,studio_service=service,usage_ledger=ledger)
    headers={'X-Veyra-Client':'inspector-v0.1'}
    with TestClient(app) as client:
        assert client.get('/api/studio/config').status_code==401
        login=client.post('/api/account/sign-in',headers=headers,json={'token':'a'*40})
        assert login.status_code==200 and 'httponly' in login.headers['set-cookie'].lower()
        assert 'a'*40 not in login.text
        assert client.get('/api/account').json()['usage']['tier']=='premium'
        assert client.post('/api/prompts/generate',headers=headers,json={'sessionId':'s','frameId':'f'}).status_code==200
        assert client.get('/api/account').json()['usage']['features']['standard_prompts']['remaining']==19
        spoof=client.post('/api/prompts/generate',headers=headers,json={'sessionId':'s','frameId':'f','tier':'boss'})
        assert spoof.status_code==422
        bob={**headers,'Authorization':'Bearer '+'b'*40}
        assert client.delete('/api/sessions/s',headers=bob).status_code==404
        assert client.post('/api/prompts/generate',headers=bob,json={'sessionId':'s','frameId':'f'}).status_code==404
        assert client.post('/api/account/sign-in',headers={**headers,'Origin':'https://evil.test'},json={'token':'a'*40}).status_code==403
        assert client.post('/api/account/sign-out',headers=headers).status_code==200
        assert client.get('/api/studio/config').status_code==401


async def test_named_providers_wire_contract_with_mock_transport(monkeypatch):
    for name in ('gemini','openrouter'):
        prefix='VEYRA_'+name.upper()+'_'
        monkeypatch.setenv(prefix+'ENABLED','true');monkeypatch.setenv(prefix+'API_KEY','test-private-key');monkeypatch.setenv(prefix+'MODEL','test-model')
        provider=named_provider(name);calls=[]
        def handler(req):
            calls.append(req);payload=json.loads(req.content)
            assert payload['model']=='test-model' and payload['max_tokens']==8192
            assert req.headers['authorization']=='Bearer test-private-key'
            return httpx.Response(200,json={'choices':[{'finish_reason':'stop','message':{'content':json.dumps({'files':{'style.css':'button{color:red}'},'summary':'Measured code'})}}], 'usage':{'total_tokens':99,'extra':'private'}})
        def factory(**kw):
            kw.pop('proxy',None);return httpx.AsyncClient(transport=httpx.MockTransport(handler),**kw)
        original=CompatibleProvider.complete
        transport=CompatibleProvider(provider.config,factory)
        async def mock_complete(self,payload,response_limit):return await original(transport,payload,response_limit)
        with monkeypatch.context() as m:
            m.setattr(CompatibleProvider,'complete',mock_complete)
            result,usage=await provider.generate({'task':'generation'})
        assert len(calls)==1 and usage=={'total_tokens':99}
        assert calls[0].url.host=={'gemini':'generativelanguage.googleapis.com','openrouter':'openrouter.ai'}[name]


async def test_local_granite_unavailable_and_mocked_endpoint():
    service=PromptService(ProviderConfig())
    result=await service.generate(evidence(),request(mode='granite'))
    assert result.mode=='fallback'
    def handler(req):
        assert str(req.url)=='http://127.0.0.1:8080/v1/chat/completions'
        assert 'reasoning_effort' not in json.loads(req.content)
        return httpx.Response(200,json={'choices':[{'finish_reason':'stop','message':{'content':json.dumps(AI_RESULT)}}]})
    def factory(**kw):return httpx.AsyncClient(transport=httpx.MockTransport(handler),**kw)
    local=GraniteProvider(GraniteConfig(enabled=True),factory)
    assert await local.generate(evidence(),request(mode='granite'))==AI_RESULT
    with pytest.raises(ValueError):replace(local.config,endpoint='http://169.254.169.254/v1/chat/completions').validate()


def cleanup_module():
    spec=importlib.util.spec_from_file_location('cleanup',Path(__file__).parents[2]/'scripts/codespace-cleanup.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module


def test_cleanup_rejects_symlinks_sources_and_tracked_files(tmp_path):
    cleanup=cleanup_module();root=tmp_path/'repo';root.mkdir();home=tmp_path/'home';home.mkdir()
    cache=root/'__pycache__';cache.mkdir();(cache/'a.pyc').write_bytes(b'disposable')
    assert cleanup.disposable(cache,root,home,set())
    assert not cleanup.disposable(cache,root,home,{cache/'a.pyc'})
    (cache/'unique.py').write_text('source')
    assert not cleanup.disposable(cache,root,home,set())
    linked=root/'link';linked.symlink_to(home,target_is_directory=True)
    assert not cleanup.disposable(linked,root,home,set())
    nested=home/'cache';nested.mkdir();(nested/'outside').symlink_to(cache,target_is_directory=True)
    assert not cleanup.disposable(nested,root,home,set())


def test_cleanup_applies_only_git_verified_backup_copies_and_caches(tmp_path):
    import subprocess
    root=tmp_path/'repo';root.mkdir();home=tmp_path/'home';home.mkdir()
    def git(*args):return subprocess.check_output(['git',*args],cwd=root)
    git('init','-q');(root/'README.md').write_text('retained source')
    git('add','README.md');git('-c','user.name=Test','-c','user.email=test@example.test','commit','-qm','baseline')
    backup=root/'.v031-backups';backup.mkdir()
    (backup/'retained.py').write_text('retained source')
    (backup/'unique.py').write_text('unique uncommitted recovery')
    (backup/'.env').write_text('retained source')
    cache=root/'backend/__pycache__';cache.mkdir(parents=True);(cache/'a.pyc').write_bytes(b'disposable')
    (root/'Veyra_duplicate.zip').write_text('retained source')
    (root/'Veyra_unique.zip').write_text('unique recovery archive')
    cleanup=cleanup_module()
    cleanup.clean(root,home,False,True)
    assert (backup/'retained.py').exists() and cache.exists()
    cleanup.clean(root,home,True,True)
    assert not (backup/'retained.py').exists() and not cache.exists()
    assert not (root/'Veyra_duplicate.zip').exists()
    assert (backup/'unique.py').exists() and (backup/'.env').exists()
    assert (root/'Veyra_unique.zip').exists() and (root/'README.md').exists()
    assert git('status','--porcelain','--untracked-files=no')==b''
