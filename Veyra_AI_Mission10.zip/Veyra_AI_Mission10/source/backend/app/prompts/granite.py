"""Optional operator-local OpenAI-compatible Granite endpoint. No downloads."""
import asyncio
from dataclasses import dataclass
import json
import os
import re
import httpx
from .provider import ProviderConfig, CompatibleProvider, ProviderFailure


@dataclass(frozen=True)
class GraniteConfig(ProviderConfig):
    name: str = 'granite-local'
    endpoint: str = 'http://127.0.0.1:8080/v1/chat/completions'
    model: str = 'granite-4.1-3b'
    timeout: float = 10
    token_parameter: str = 'max_tokens'

    def validate(self):
        # Only an explicit local sidecar, never a user-supplied URL or phone bridge.
        if not re.fullmatch(r'http://127\.0\.0\.1:[0-9]{1,5}/v1/chat/completions',self.endpoint):
            raise ValueError('Granite requires an operator-local loopback endpoint.')
        port=int(self.endpoint.split(':')[2].split('/')[0])
        if not 1<=port<=65535 or not 1<=self.timeout<=15 or not 128<=self.max_tokens<=1500:
            raise ValueError('Invalid local model limits.')
        if not re.fullmatch(r'[A-Za-z0-9._/-]{1,100}',self.model):raise ValueError('Invalid local model identifier.')

    @property
    def available(self):return self.enabled


class GraniteProvider(CompatibleProvider):
    def __init__(self, config=None, client_factory=httpx.AsyncClient):
        if config is None:
            try:
                config=GraniteConfig(enabled=os.getenv('VEYRA_GRANITE_ENABLED','false').lower()=='true',
                    endpoint=os.getenv('VEYRA_GRANITE_ENDPOINT',GraniteConfig.endpoint),
                    model=os.getenv('VEYRA_GRANITE_MODEL',GraniteConfig.model))
                config.validate()
            except ValueError:config=GraniteConfig()
        super().__init__(config,client_factory)

    async def complete(self,payload,response_limit=64000):
        self.config.validate()
        if len(json.dumps(payload).encode())>64000:raise ProviderFailure('input-limit')
        try:
            async with asyncio.timeout(self.config.timeout):
                async with self.client_factory(trust_env=False,follow_redirects=False,timeout=self.config.timeout) as client:
                    async with client.stream('POST',self.config.endpoint,json=payload) as response:
                        if response.status_code!=200:raise ProviderFailure('http-error')
                        body=bytearray()
                        async for chunk in response.aiter_bytes():
                            if len(body)+len(chunk)>response_limit:raise ProviderFailure('output-limit')
                            body.extend(chunk)
                return json.loads(body)
        except ProviderFailure:raise
        except (asyncio.TimeoutError,httpx.TimeoutException):raise ProviderFailure('timeout') from None
        except (httpx.HTTPError,OSError,ValueError):raise ProviderFailure('connection') from None
