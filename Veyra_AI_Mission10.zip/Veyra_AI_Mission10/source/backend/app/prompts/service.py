import asyncio
from collections import deque
from contextlib import asynccontextmanager
import secrets
import time
from ..browser_manager import SessionError
from .deterministic import render_prompt
from .compact import render_compact
from .provider import CompatibleProvider, ProviderConfig, ProviderFailure
from .schemas import PromptResponse
from .report import quality_report
from .granite import GraniteProvider


class PromptService:
    def __init__(self, config=None, provider=None):
        self.config=config or ProviderConfig.from_env()
        self.provider=provider or CompatibleProvider(self.config)
        self.granite=GraniteProvider()
        self.lock=asyncio.Lock();self.requests=deque(maxlen=12)

    @asynccontextmanager
    async def admission(self, session_id):
        now=time.monotonic()
        while self.requests and now-self.requests[0][0]>=60:self.requests.popleft()
        if self.lock.locked():raise SessionError('A prompt is already being generated. Please wait.',429,'prompt-busy')
        if len(self.requests)>=10 or sum(token==session_id for _,token in self.requests)>=3:
            raise SessionError('Prompt limit reached. Wait one minute before trying again.',429,'prompt-rate-limit')
        async with self.lock:
            self.requests.append((now,session_id));yield

    async def generate(self, evidence, request):
        ai=None;warning=None;usage={}
        active_provider=self.granite if request.mode=='granite' else self.provider
        active_config=self.granite.config if request.mode=='granite' else self.config
        if request.mode in ('auto','granite'):
            if not active_config.available:warning='AI is not configured or enabled. The local deterministic generator was used.'
            else:
                try:
                    ai=await active_provider.generate(evidence,request)
                    usage=getattr(active_provider,'last_usage',{})
                except ProviderFailure as exc:
                    messages={'timeout':'timed out','rate-limit':'was rate limited','configuration':'has invalid configuration'}
                    warning=f'AI {messages.get(exc.reason,"was unavailable or returned unusable output")}. The local deterministic generator was used; no automatic retry was made.'
        try:
            renderer=render_prompt if request.lengthMode=='detailed' else render_compact
            prompt,warnings=renderer(evidence,request,ai)
        except (KeyError,TypeError,ValueError):
            prompt,warnings=render_prompt(evidence,request,ai)
            warnings.append('Compact rendering was unavailable; the established detailed generator was used.')
        if warning:warnings.append(warning)
        if len(prompt)>60000:raise SessionError('The evidence exceeded the prompt output budget. Choose Concise.',422,'prompt-output-limit')
        return PromptResponse(generationId=secrets.token_hex(12),prompt=prompt,mode='ai' if ai else 'fallback',usage=usage,
            provider=active_config.name if ai else None,model=active_config.model if ai else None,warnings=warnings,
            evidenceSummary={'scope':request.scope,'rootTag':evidence['nodes'][0]['tag'],'boundary':evidence['boundary'],
                             'nodeCount':len(evidence['nodes']),'viewport':evidence['viewport'],'truncated':evidence['truncated'],
                             'capturedAt':evidence['source']['capturedAt'],
                             'qualityReport':quality_report(evidence,request,warnings)})
