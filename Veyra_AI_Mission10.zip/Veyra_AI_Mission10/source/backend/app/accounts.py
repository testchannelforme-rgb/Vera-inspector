"""Provisioned test accounts and atomic provisional quotas; no payments/billing."""
from contextvars import ContextVar
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
import hashlib
import hmac
import json
import os
from pathlib import Path
import re
import sqlite3
from .browser_manager import SessionError


@dataclass(frozen=True)
class Account:
    id: str = 'operator'
    tier: str = 'free'


account_context = ContextVar('veyra_account', default=Account())
ledger_context = ContextVar('veyra_ledger', default=None)
DEFAULTS = {
    'free': dict(standard_prompts=10, enhanced_prompts=0, basic_code=2, openrouter_code=0, gemini_code=0),
    'premium': dict(standard_prompts=20, enhanced_prompts=8, basic_code=6, openrouter_code=2, gemini_code=1),
    'boss': dict(standard_prompts=30, enhanced_prompts=15, basic_code=12, openrouter_code=4, gemini_code=2),
}


def bounded_env(name, default):
    value = int(os.getenv(name, str(default)))
    if not 0 <= value <= 10_000_000:
        raise ValueError('Invalid limit: ' + name)
    return value


class Accounts:
    def __init__(self):
        raw = json.loads(os.getenv('VEYRA_USERS_JSON', '{}') or '{}')
        if not isinstance(raw, dict):
            raise ValueError('VEYRA_USERS_JSON must be an account map.')
        self.users = []
        for name, record in raw.items():
            if not re.fullmatch(r'[A-Za-z0-9_-]{1,64}', name) or not isinstance(record, dict):
                raise ValueError('Invalid account configuration.')
            token, tier = record.get('token', ''), record.get('tier', 'free')
            if not isinstance(token, str) or not 32 <= len(token) <= 256 or tier not in DEFAULTS:
                raise ValueError('Accounts require a unique random token (32–256 characters) and a valid tier.')
            digest = hashlib.sha256(token.encode()).digest()
            if any(hmac.compare_digest(digest, d) for d, _ in self.users):
                raise ValueError('Account tokens must be unique.')
            self.users.append((digest, Account(name, tier)))
        tier = os.getenv('VEYRA_OPERATOR_PLAN', 'free')
        self.operator = Account(tier=tier if tier in DEFAULTS else 'free')

    def authenticate(self, token):
        if not self.users:
            return self.operator
        digest = hashlib.sha256(token.encode()).digest()
        for expected, account in self.users:
            if hmac.compare_digest(digest, expected):
                return account
        raise SessionError('Sign in with your provisioned access token.', 401, 'authentication-required')


class UsageLedger:
    def __init__(self, db=None, clock=None):
        self.clock = clock or (lambda: datetime.now(timezone.utc))
        self.limits = {}
        lower = {k: 0 for k in DEFAULTS['free']}
        for tier, values in DEFAULTS.items():
            # Inheritance is enforced even if a higher-tier override is smaller.
            self.limits[tier] = {k: max(lower[k], bounded_env('VEYRA_QUOTA_' + tier.upper() + '_' + k.upper(), v)) for k, v in values.items()}
            lower = self.limits[tier]
        db = db or os.getenv('VEYRA_ACCOUNT_USAGE_DB', '.veyra-runtime/accounts.sqlite3')
        if db != ':memory:':
            Path(db).parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(db, timeout=5, check_same_thread=False, isolation_level=None)
        self.db.execute('CREATE TABLE IF NOT EXISTS daily_usage(day TEXT, subject TEXT, feature TEXT, count INTEGER NOT NULL, PRIMARY KEY(day,subject,feature))')
        self.db.execute('PRAGMA busy_timeout=5000')

    def _reserve(self, rows):
        day = self.clock().astimezone(timezone.utc).date().isoformat()
        self.db.execute('BEGIN IMMEDIATE')
        try:
            for subject, feature, amount, limit in rows:
                self.db.execute('INSERT OR IGNORE INTO daily_usage VALUES(?,?,?,0)', (day, subject, feature))
                updated = self.db.execute('UPDATE daily_usage SET count=count+? WHERE day=? AND subject=? AND feature=? AND count+?<=?', (amount, day, subject, feature, amount, limit))
                if updated.rowcount != 1:
                    raise SessionError('Daily allowance reached or feature unavailable: ' + feature.replace('_', ' ') + '.', 429, 'daily-quota')
            self.db.execute('COMMIT')
        except BaseException:
            self.db.execute('ROLLBACK')
            raise

    def charge(self, feature, account=None):
        account = account or account_context.get()
        self._reserve([(account.id, feature, 1, self.limits[account.tier][feature])])

    def reserve_provider(self, provider, output_tokens):
        name = re.sub('[^A-Z0-9]', '_', provider.upper())
        requests = bounded_env('VEYRA_EXTERNAL_REQUESTS_PER_DAY', 0)
        provider_requests = bounded_env('VEYRA_PROVIDER_' + name + '_REQUESTS_PER_DAY', 0)
        tokens = bounded_env('VEYRA_EXTERNAL_OUTPUT_TOKENS_PER_DAY', 0)
        # Reserve worst-case output before making a network call. No retries.
        self._reserve([('@providers', 'all_requests', 1, requests),
                       ('@providers', name + '_requests', 1, provider_requests),
                       ('@providers', 'reserved_output_tokens', output_tokens, tokens)])

    def snapshot(self, account=None):
        account = account or account_context.get()
        now = self.clock().astimezone(timezone.utc)
        day = now.date().isoformat()
        used = dict(self.db.execute('SELECT feature,count FROM daily_usage WHERE day=? AND subject=?', (day, account.id)))
        return {'account': account.id, 'tier': account.tier, 'provisional': True, 'resetTimezone': 'UTC',
                'resetsAt': datetime.combine(now.date() + timedelta(days=1), datetime.min.time(), timezone.utc).isoformat(),
                'features': {k: {'limit': v, 'used': used.get(k, 0), 'remaining': max(0, v-used.get(k, 0))} for k, v in self.limits[account.tier].items()},
                'accounting': 'Admitted attempts count, including failed provider calls. Provider token reservations are conservative upper bounds; response usage is reported separately.'}


def code_feature(provider):
    name = provider.config.name.lower()
    return 'gemini_code' if 'gemini' in name else 'openrouter_code' if 'openrouter' in name else 'enhanced_prompts'
