#!/usr/bin/env python3
"""Build a source/bundle release and verify the guarded install in a disposable repo."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import zipfile

ROOT=Path(__file__).resolve().parents[1]
BASE='361cb5b352c5b78b8df508b5b4fa65041bc07d59'
BRANCH='feature/mission-10-stability'


def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)


def package(destination):
    revision=git('rev-parse','HEAD').decode().strip()
    if git('status','--porcelain','--untracked-files=no').strip():raise RuntimeError('Commit tracked changes before packaging.')
    with tempfile.TemporaryDirectory(prefix='veyra-mission10-') as td:
        root=Path(td);release=root/'Veyra_AI_Mission10';release.mkdir()
        for src,dest in [('scripts/codespace-cleanup.py','codespace-cleanup.py'),('scripts/install-mission10.py','apply_mission10.py'),('docs/MISSION10_INSTALL.md','INSTALL.md'),('docs/MISSION10_REPORT.md','REPORT.md')]:
            shutil.copyfile(ROOT/src,release/dest)
        subprocess.run(['git','bundle','create',str(release/'mission10.bundle'),BASE+'..'+BRANCH],cwd=ROOT,check=True)
        (release/'mission10.patch').write_bytes(git('diff','--binary',BASE,'HEAD'))
        (release/'RELEASE.json').write_text(json.dumps({'application':'VEYRA AI','version':'0.4.2-mission10','branch':BRANCH,'commit':revision,'baseline':BASE,'pushed':False},indent=2)+'\n')
        for name in git('ls-files').decode().splitlines():
            if name.endswith('.zip') or name.startswith(('artifacts/','docs/review/')):continue
            source=ROOT/name
            if not source.is_file() or source.is_symlink():continue
            target=release/'source'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
        hashes={p.relative_to(release).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(release.rglob('*')) if p.is_file()}
        (release/'SHA256.json').write_text(json.dumps(hashes,indent=2)+'\n')
        # Exercise bundle prerequisites, non-destructive branch switching, and guards.
        check=root/'checkout';check.mkdir()
        subprocess.run(['git','init','-q',str(check)],check=True)
        subprocess.run(['git','fetch','-q',str(ROOT),BASE+':refs/heads/baseline'],cwd=check,check=True)
        subprocess.run(['git','switch','-q','baseline'],cwd=check,check=True)
        (check/'.env').write_text('MISSION10_SYNTHETIC_SECRET=preserve\n')
        (check/'unique-notes.txt').write_text('preserve this user note\n')
        command=['python3',str(release/'apply_mission10.py'),'--repo',str(check)]
        subprocess.run(command,cwd=check,check=True)
        subprocess.run(command+['--apply'],cwd=check,check=True)
        assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=check).decode().strip()==revision
        assert (check/'.env').read_text()=='MISSION10_SYNTHETIC_SECRET=preserve\n'
        assert (check/'unique-notes.txt').read_text()=='preserve this user note\n'
        subprocess.run(command+['--apply'],cwd=check,check=True) # idempotent
        original=(check/'README.md').read_text();(check/'README.md').write_text(original+'\nUncommitted user change\n')
        rejected=subprocess.run(command+['--apply'],cwd=check,capture_output=True,text=True)
        assert rejected.returncode!=0 and 'local changes' in rejected.stderr+rejected.stdout
        assert 'Uncommitted user change' in (check/'README.md').read_text()
        (release/'PACKAGING_RESULT.json').write_text(json.dumps({'commit':revision,'installer':'passed','checks':['bundle prerequisites','package SHA256','check-only','branch install','idempotence','tracked local-change refusal','.env preservation','untracked note preservation']},indent=2)+'\n')
        hashes={p.relative_to(release).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(release.rglob('*')) if p.is_file() and p.name!='SHA256.json'}
        (release/'SHA256.json').write_text(json.dumps(hashes,indent=2)+'\n')
        destination.parent.mkdir(parents=True,exist_ok=True)
        with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED) as archive:
            for p in sorted(release.rglob('*')):
                if p.is_file():archive.write(p,p.relative_to(root))
        with zipfile.ZipFile(destination) as archive:assert archive.testzip() is None
    print(json.dumps({'file':str(destination),'bytes':destination.stat().st_size,'commit':revision,'installerChecks':'check, install, idempotence, uncommitted-change refusal, .env preservation, untracked note preservation; ZIP CRC passed'}))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('output',type=Path);args=parser.parse_args();package(args.output.resolve())
