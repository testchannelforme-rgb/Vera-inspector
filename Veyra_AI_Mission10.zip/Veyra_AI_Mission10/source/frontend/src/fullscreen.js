import {useEffect,useRef,useState} from 'react';
const EVENT='veyra:fullscreen';
// Intent is set only by an explicit control/shortcut; native events cannot enter.
export function useFullscreen(id){
 const ref=useRef(null),intent=useRef(false),nativeRef=useRef(false),epoch=useRef(0),previous=useRef(null);
 const [active,setActive]=useState(false),[native,setNative]=useState(false);
 function reset(restore=true){intent.current=false;nativeRef.current=false;epoch.current++;setActive(false);setNative(false);if(restore)previous.current?.focus?.({preventScroll:true});}
 async function exit(){const own=document.fullscreenElement===ref.current;reset();if(own)try{await document.exitFullscreen?.();}catch{}}
 async function toggle(){
  if(intent.current){await exit();return;}
  if(!ref.current||globalThis.navigator?.userActivation?.isActive===false)return;
  window.dispatchEvent(new CustomEvent(EVENT,{detail:id}));
  if(document.fullscreenElement)try{await document.exitFullscreen?.();}catch{}
  previous.current=document.activeElement;intent.current=true;const token=++epoch.current;setActive(true);
  ref.current.tabIndex=-1;ref.current.focus({preventScroll:true});
  try{if(ref.current.requestFullscreen){await ref.current.requestFullscreen();if(token===epoch.current&&intent.current){nativeRef.current=true;setNative(true);}else if(document.fullscreenElement===ref.current)await document.exitFullscreen?.();}}catch{}
 }
 useEffect(()=>{
  const other=e=>{if(e.detail!==id)reset(false);};
  const change=()=>{if(!intent.current)return;if(document.fullscreenElement===ref.current){nativeRef.current=true;setNative(true);}else if(nativeRef.current)reset();};
  const keys=e=>{if(!intent.current)return;if(e.key==='Escape'){e.preventDefault();exit();return;}if(e.key!=='Tab'||!ref.current)return;const controls=[...ref.current.querySelectorAll('button:not(:disabled),a[href],input:not(:disabled),select:not(:disabled),textarea:not(:disabled),[contenteditable=true]')].filter(n=>n.getClientRects().length);const first=controls[0],last=controls.at(-1);if(e.shiftKey&&(document.activeElement===first||document.activeElement===ref.current)){e.preventDefault();last?.focus();}else if(!e.shiftKey&&(document.activeElement===last||document.activeElement===ref.current)){e.preventDefault();first?.focus();}};
  const route=()=>exit();
  window.addEventListener(EVENT,other);window.addEventListener('keydown',keys);window.addEventListener('hashchange',route);document.addEventListener('fullscreenchange',change);
  return()=>{epoch.current++;intent.current=false;window.removeEventListener(EVENT,other);window.removeEventListener('keydown',keys);window.removeEventListener('hashchange',route);document.removeEventListener('fullscreenchange',change);if(document.fullscreenElement===ref.current)document.exitFullscreen?.().catch(()=>{});};
 },[id]);
 return {ref,active,native,toggle,exit,className:active?' workspace-fullscreen':''};
}
