import React,{useEffect,useState} from 'react';
import {setStorageAccount} from '../local-data.js';
import {api} from '../api.js';
const labels={standard_prompts:'Standard prompts',enhanced_prompts:'Enhanced prompts',basic_code:'Basic code',openrouter_code:'OpenRouter code',gemini_code:'Gemini code'};
export default function AccountPanel({onAccount=()=>{}}){
 const [data,setData]=useState(null),[token,setToken]=useState(''),[error,setError]=useState(''),[busy,setBusy]=useState(false);
 const refresh=()=>api('/account',undefined,'GET').then(d=>{setStorageAccount(d.authenticated?d.usage.account:'signed-out');setData(d);onAccount(d);}).catch(e=>setError(e.message));
 useEffect(()=>{refresh();window.addEventListener('veyra:usage-changed',refresh);window.addEventListener('veyra:account-changed',refresh);return()=>window.removeEventListener('veyra:usage-changed',refresh);window.removeEventListener('veyra:account-changed',refresh);},[]);
 async function signIn(e){e.preventDefault();setBusy(true);setError('');try{await api('/account/sign-in',{token});setToken('');await refresh();window.dispatchEvent(new Event('veyra:account-changed'));}catch(e){setError(e.message);}finally{setBusy(false);}}
 return <section className="account-panel" aria-label="Account and daily usage">{data?.authenticated?<><strong>{data.usage.tier} · provisional daily limits</strong><div className="usage-indicators">{Object.entries(data.usage.features).map(([k,v])=><span key={k}>{labels[k]}: {v.remaining}/{v.limit} remaining</span>)}</div><small>Resets at 00:00 UTC · {data.scope}</small>{data.authenticationRequired&&<button onClick={async()=>{await api('/account/sign-out');setData(null);await refresh();window.dispatchEvent(new Event('veyra:account-changed'));}}>Sign out</button>}</>:data?.authenticationRequired?<form onSubmit={signIn}><label>Access token<input aria-label="Access token" type="password" autoComplete="off" maxLength={256} value={token} onChange={e=>setToken(e.target.value)}/></label><button disabled={busy||!token}>Sign in</button></form>:<small>Checking daily usage…</small>}{error&&<p role="alert">{error}</p>}</section>;
}
