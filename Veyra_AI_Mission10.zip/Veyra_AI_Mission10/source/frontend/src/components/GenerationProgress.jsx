import React from 'react';
export default function GenerationProgress({events=[],working=false}){
 if(!events.length)return null;
 return <ol className="generation-progress" aria-label="Generation stages" aria-live="polite">{events.map((e,i)=><li key={i} aria-current={working&&i===events.length-1?'step':undefined}><span>{i+1}</span>{e.stage}</li>)}</ol>;
}
