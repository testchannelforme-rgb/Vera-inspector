import test from 'node:test';
import assert from 'node:assert/strict';
import React from 'react';
import {act,create} from 'react-test-renderer';
import {useFullscreen} from '../src/fullscreen.js';
globalThis.IS_REACT_ACT_ENVIRONMENT=true;
function environment(){
 const window=new EventTarget(),document=new EventTarget();
 const focus={calls:0,focus(){this.calls++;}};document.activeElement=focus;document.fullscreenElement=null;
 document.exitFullscreen=async()=>{document.fullscreenElement=null;document.dispatchEvent(new Event('fullscreenchange'));};
 globalThis.window=window;globalThis.document=document;
 Object.defineProperty(globalThis,'navigator',{configurable:true,value:{userActivation:{isActive:true}}});
 const node={tabIndex:0,focus(){document.activeElement=this;},querySelectorAll(){return [];}};
 return {window,document,focus,node};
}
async function mount(id,node){let value;function Harness(){value=useFullscreen(id);return null;}let tree;await act(()=>{tree=create(React.createElement(Harness));});value.ref.current=node;return {get value(){return value;},async unmount(){await act(()=>tree.unmount());}};}
test('native fullscreen cannot activate without intent; explicit enter, Escape and focus restoration work',async()=>{
 const e=environment();e.node.requestFullscreen=async()=>{e.document.fullscreenElement=e.node;e.document.dispatchEvent(new Event('fullscreenchange'));};
 const h=await mount('preview',e.node);
 await act(()=>e.document.dispatchEvent(new Event('fullscreenchange')));assert.equal(h.value.active,false);
 await act(()=>h.value.toggle());assert.equal(h.value.active,true);assert.equal(h.value.native,true);
 const key=new Event('keydown',{cancelable:true});Object.defineProperty(key,'key',{value:'Escape'});
 await act(()=>e.window.dispatchEvent(key));assert.equal(h.value.active,false);assert.equal(e.document.fullscreenElement,null);assert.ok(e.focus.calls>0);
 await h.unmount();
});
test('mobile fallback switches independent panels and exits on navigation',async()=>{
 const e=environment(),h=await mount('editor',e.node),other=await mount('inspector',{...e.node});
 await act(()=>h.value.toggle());assert.equal(h.value.active,true);assert.equal(h.value.native,false);
 await act(()=>other.value.toggle());assert.equal(h.value.active,false);assert.equal(other.value.active,true);
 await act(()=>e.window.dispatchEvent(new Event('hashchange')));assert.equal(other.value.active,false);
 await h.unmount();await other.unmount();
});
test('late native resolution cannot reopen exited panels; inactive script calls are rejected',async()=>{
 const e=environment();let resolve;e.node.requestFullscreen=()=>new Promise(r=>{resolve=r;});
 const h=await mount('preview',e.node);let pending;
 await act(()=>{pending=h.value.toggle();});assert.equal(h.value.active,true);
 await act(()=>h.value.exit());
 await act(async()=>{e.document.fullscreenElement=e.node;resolve();await pending;});
 assert.equal(h.value.active,false);assert.equal(e.document.fullscreenElement,null);
 navigator.userActivation.isActive=false;await act(()=>h.value.toggle());assert.equal(h.value.active,false);
 await h.unmount();
});
