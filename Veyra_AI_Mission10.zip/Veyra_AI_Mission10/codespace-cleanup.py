#!/usr/bin/env python3
"""Audit by default; --apply removes verified disposable caches only.

Run from any directory. Never removes dependencies, browser installs, volumes,
containers, databases, backups, Git data, tracked files or changed archives.
"""
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess


def command(args, cwd=None, timeout=60):
    try:
        p = subprocess.run(args, cwd=cwd, text=True, capture_output=True, timeout=timeout)
        return p.stdout.strip() if p.returncode == 0 else ''
    except (OSError, subprocess.TimeoutExpired):
        return ''


def inventory(root):
    for args in (['df', '-h', '/'], ['df', '-i', '/'],
                 ['du', '-h', '--max-depth=1', '/workspaces'],
                 ['du', '-h', '--max-depth=1', '/home/codespace'],
                 ['du', '-h', '--max-depth=2', str(root)], ['docker', 'system', 'df']):
        print('$', ' '.join(args), flush=True)
        print(command(args) or '(unavailable)', flush=True)


def candidates(root, home):
    # These locations hold download caches, not installed dependencies.
    for rel in ('.cache/pip', '.npm/_cacache', '.cache/yarn'):
        yield home / rel
    for base, dirs, _ in os.walk(root, followlinks=False):
        if Path(base) != root and (Path(base) / '.git').exists():
            dirs[:] = []
            continue
        dirs[:] = [d for d in dirs if d not in {'.git', 'node_modules', '.venv', 'venv', '.veyra-runtime'}
                   and 'backup' not in d.lower()
                   and not (Path(base) / d).is_symlink()]
        for name in list(dirs):
            if name in {'__pycache__', '.pytest_cache', '.ruff_cache', '.mypy_cache'}:
                yield Path(base) / name
                dirs.remove(name)
    yield root / 'frontend/node_modules/.vite'


def disposable(path, root, home, tracked):
    # Reject symlinks at every level, even a symlinked .cache or home parent.
    if path.is_symlink() or not path.is_dir():
        return False
    if any(p.is_symlink() for p in path.parents):
        return False
    resolved = path.resolve()
    if resolved == root or resolved == home or not (resolved.is_relative_to(root) or resolved.is_relative_to(home)):
        return False
    if any(p == resolved or resolved in p.parents for p in tracked):
        return False
    for base, dirs, files in os.walk(path, followlinks=False):
        if any((Path(base) / n).is_symlink() for n in dirs + files):
            return False
        if '.git' in dirs or any(n.endswith(('.py', '.jsx', '.tsx', '.sqlite3', '.db', '.env')) for n in files):
            return False
        if path.name == '__pycache__' and any(not n.endswith('.pyc') for n in files):
            return False
    return True


def redundant_archives(root, tracked):
    """Only untracked root update ZIPs with identical bytes retained in Git history."""
    reachable = {line.split(' ', 1)[0] for line in command(['git', 'rev-list', '--objects', '--all'], root).splitlines()}
    for path in root.glob('Veyra*.zip'):
        if path in tracked or path.is_symlink() or not path.is_file():
            continue
        digest = command(['git', 'hash-object', '--', str(path)], root)
        if digest and digest in reachable:
            yield path


def verified_backups(root, tracked):
    """Untracked historical copies only; unique recovery files remain untouched."""
    reachable = {line.split(' ', 1)[0] for line in command(['git', 'rev-list', '--objects', '--all'], root).splitlines()}
    for name in ('.v02-backups', '.v031-backups', '.v032-backups', '.v04-backups'):
        parent = root / name
        if not parent.is_dir() or parent.is_symlink():
            continue
        # Refuse backup roots currently used by any process we can inspect.
        active = False
        for process in Path('/proc').glob('[0-9]*'):
            try:
                if Path(os.readlink(process / 'cwd')).is_relative_to(parent):
                    active = True
                if str(parent).encode() in (process / 'cmdline').read_bytes():
                    active = True
            except (OSError, ValueError):
                pass
        if active:
            print('PRESERVE active backup root:', parent)
            continue
        for base, dirs, files in os.walk(parent, followlinks=False):
            dirs[:] = [d for d in dirs if d not in {'.git', '.venv', 'venv', 'node_modules', '.veyra-runtime'} and not (Path(base)/d).is_symlink()]
            for filename in files:
                path = Path(base) / filename
                if path.is_symlink() or path in tracked or any(p.is_symlink() for p in path.parents):
                    continue
                if any(word in filename.lower() for word in ('.env', 'secret', 'credential', 'token', 'password', '.db', '.sqlite')):
                    continue
                digest = command(['git', 'hash-object', '--', str(path)], root)
                if digest in reachable:
                    yield path, digest


def clean(root, home, apply=False, backups=False):
    listing = command(['git', 'ls-files', '-z'], root)
    top = command(['git', 'rev-parse', '--show-toplevel'], root)
    if not top or Path(top).resolve() != root or not listing:
        raise RuntimeError('A populated Git checkout is required; nothing was removed.')
    tracked = {root / p for p in listing.split('\0') if p}
    total = 0
    for path in dict.fromkeys(candidates(root, home)):
        if not disposable(path, root, home, tracked):
            continue
        size = sum(p.stat().st_size for p in path.rglob('*') if p.is_file())
        print(('REMOVE' if apply else 'WOULD REMOVE'), str(path), size, 'bytes', flush=True)
        if apply:
            shutil.rmtree(path)
        total += size
    for path in redundant_archives(root, tracked):
        size = path.stat().st_size
        print(('REMOVE' if apply else 'WOULD REMOVE'), str(path), size, 'bytes (identical blob in reachable Git history)', flush=True)
        if apply:
            path.unlink()
        total += size
    if backups:
        for path, digest in verified_backups(root, tracked):
            size = path.stat().st_size
            print(('REMOVE' if apply else 'WOULD REMOVE'), str(path), size, 'bytes (Git recovery blob '+digest+')', flush=True)
            if apply:
                path.unlink()
            total += size
    # Unknown archives/backups/logs are inventory only, regardless of their names.
    print('Preserved archive/backup candidates (manual content verification required):')
    for path in sorted(root.iterdir()):
        if path.suffix in {'.zip', '.tar', '.gz', '.bak'} or 'backup' in path.name.lower():
            print(str(path))
    return total


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo', help='Git checkout to clean; defaults to the current checkout.')
    p.add_argument('--apply', action='store_true')
    p.add_argument('--verified-backups', action='store_true', help='Remove only exact Git-retained copies in known historical backup roots; preserve unique files.')
    p.add_argument('--docker-cache', action='store_true', help='Also prune build cache and dangling images older than seven days; no volumes or containers.')
    args = p.parse_args()
    root = Path(args.repo).resolve() if args.repo else Path(command(['git', 'rev-parse', '--show-toplevel']) or Path(__file__).resolve().parents[1])
    before = shutil.disk_usage(root)
    inventory(root)
    planned = clean(root, Path.home(), args.apply, args.verified_backups)
    if args.docker_cache:
        for cmd in (['docker', 'builder', 'prune', '--force', '--filter', 'until=168h'],
                    ['docker', 'image', 'prune', '--force', '--filter', 'until=168h']):
            print('$', ' '.join(cmd), flush=True)
            print(command(cmd, timeout=60) if args.apply else '(audit only; add --apply)')
    after = shutil.disk_usage(root)
    report = {'applied': args.apply, 'totalBytes': before.total, 'beforeUsedBytes': before.used,
              'beforeFreeBytes': before.free, 'afterUsedBytes': after.used, 'afterFreeBytes': after.free,
              'observedRecoveredGB': round((after.free - before.free) / 1e9, 4),
              'candidateBytes': planned, 'freePercent': round(100 * after.free / after.total, 2),
              'target50PercentReached': after.free >= after.total / 2}
    print(json.dumps(report, indent=2))
    print('$ df -h /\n' + command(['df', '-h', '/']))
    print('$ docker system df\n' + (command(['docker', 'system', 'df']) or '(unavailable)'))


if __name__ == '__main__':
    main()
