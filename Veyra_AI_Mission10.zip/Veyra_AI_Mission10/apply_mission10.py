#!/usr/bin/env python3
"""Install the reviewed Git bundle on a new branch; never reset or force checkout."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess


def run(args, cwd, capture=True):
    return subprocess.check_output(args, cwd=cwd, text=True).strip() if capture else subprocess.check_call(args,cwd=cwd)


def install(repo, release, apply=False):
    repo=repo.resolve();release=release.resolve()
    manifest=json.loads((release/'SHA256.json').read_text())
    for name,digest in manifest.items():
        path=(release/name).resolve()
        if not path.is_relative_to(release) or hashlib.sha256(path.read_bytes()).hexdigest()!=digest:
            raise RuntimeError('Package integrity check failed: '+name)
    info=json.loads((release/'RELEASE.json').read_text())
    bundle=release/'mission10.bundle';branch=info['branch'];revision=info['commit']
    if run(['git','rev-parse','--show-toplevel'],repo)!=str(repo):raise RuntimeError('Use the Git checkout root.')
    if run(['git','status','--porcelain','--untracked-files=no'],repo):
        raise RuntimeError('Tracked local changes exist. Commit or preserve them before installing; nothing was overwritten.')
    current=run(['git','rev-parse','HEAD'],repo)
    run(['git','bundle','verify',str(bundle)],repo,False)
    heads=run(['git','bundle','list-heads',str(bundle)],repo)
    if f'{revision} refs/heads/{branch}' not in heads.splitlines():raise RuntimeError('Bundle does not match the release revision.')
    existing=subprocess.run(['git','rev-parse','--verify','refs/heads/'+branch],cwd=repo,capture_output=True,text=True)
    if existing.returncode==0:
        if existing.stdout.strip()!=revision:raise RuntimeError('Mission branch already exists with different work. It was not changed.')
        if current==revision:print('This revision is already checked out.');return
    print('Validated revision:',revision,'on branch',branch)
    print('Recovery commit:',current,'; all existing branches and ignored runtime data are preserved.')
    if not apply:print('Check only. Add --apply to install.');return
    ref='refs/remotes/mission10/'+revision[:12]
    run(['git','fetch',str(bundle),'refs/heads/'+branch+':'+ref],repo,False)
    tag='recovery/mission10-'+current[:12]
    if subprocess.run(['git','show-ref','--verify','--quiet','refs/tags/'+tag],cwd=repo).returncode!=0:
        run(['git','tag',tag,current],repo,False)
    if existing.returncode==0:run(['git','switch',branch],repo,False)
    else:run(['git','switch','-c',branch,ref],repo,False)
    assert run(['git','rev-parse','HEAD'],repo)==revision
    print('Installed. No dependencies, secrets, databases or Docker volumes were removed. Nothing was pushed.')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo',default='.')
    p.add_argument('--release',default=str(Path(__file__).resolve().parent))
    p.add_argument('--apply',action='store_true')
    args=p.parse_args()
    try:install(Path(args.repo),Path(args.release),args.apply)
    except (RuntimeError,subprocess.CalledProcessError,OSError,ValueError) as exc:raise SystemExit(str(exc))


if __name__=='__main__':main()
