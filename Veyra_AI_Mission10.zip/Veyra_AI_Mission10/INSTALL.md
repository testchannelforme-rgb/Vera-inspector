# VEYRA AI Mission 10 — installation and recovery

This update extends the existing V0.4.2 Blue Hour application. It is a development candidate, not V0.7 and not a paid subscription release.

## Run cleanup first

Extract `Veyra_AI_Mission10.zip` outside the repository. From the Codespaces terminal, use the extracted directory in place of `/path/to/Veyra_AI_Mission10` and your checkout in place of `/workspaces/Vera-inspector`.

```bash
python /path/to/Veyra_AI_Mission10/codespace-cleanup.py --repo /workspaces/Vera-inspector
python /path/to/Veyra_AI_Mission10/codespace-cleanup.py --repo /workspaces/Vera-inspector --apply --docker-cache --verified-backups
```

The first command audits. The second removes verified disposable items and prints actual before/after bytes, recovered GB and free percentage. Docker options prune only build cache and dangling images older than seven days. No containers or volumes are pruned. Missing Docker is reported as unavailable.

Known historical backup roots are inspected file by file. Only untracked files whose exact bytes remain reachable in Git history can be removed. Unique files, secret-like names, databases, active backup roots, virtual environments and dependency directories remain. Unknown ZIPs and duplicate directories require further inspection. No space target justifies deleting these blindly.

If 50% free cannot be reached, retain the audit output. Large active Docker images, persistent volumes, current dependencies, browser installations and unique backups need a separate, evidence-based decision.

## Install on a new branch

```bash
python /path/to/Veyra_AI_Mission10/apply_mission10.py --repo /workspaces/Vera-inspector
python /path/to/Veyra_AI_Mission10/apply_mission10.py --repo /workspaces/Vera-inspector --apply
cd /workspaces/Vera-inspector
bash scripts/setup.sh
bash start.sh --isolated
```

The installer verifies package hashes and the bundle's prerequisite commit. It refuses tracked local modifications or an existing mission branch with different work. Git also refuses untracked path collisions when switching. It creates a recovery tag and switches to a new mission branch. It never resets, forces a checkout, removes branches, rewrites history or pushes.

If bundle verification reports a missing prerequisite, fetch the existing V0.4.2 branch first:

```bash
git fetch origin feature/v0.4.2-blue-hour
```

An occupied port is reported without killing its process. Check that process's `/api/health` before stopping it yourself. The isolated launcher preserves the existing gateway, firewall and Chromium sandbox checks; there is no unrestricted public browsing fallback.

Keep port 8001 private for single-operator testing. Check `/api/health` for version `0.4.2`, the installed commit and browser readiness. The application version intentionally remains V0.4.2 with Mission 10 fixes.

## Configuration

- Compose reads an ignored `.env`; local non-Compose mode requires exported variables/Codespaces secrets. The committed `.env.example` contains configuration names and safe defaults only.
- `VEYRA_USERS_JSON` provisions private testers with unique random tokens (at least 32 characters) and server-selected `free`, `premium` or `boss` tiers. Empty configuration preserves single-operator mode; it is not public signup/authentication.
- Sign-in sets an HttpOnly SameSite=Strict cookie, Secure over HTTPS. Use HTTPS for any shared deployment. Tokens are not saved into localStorage or the usage database.
- Quotas use `VEYRA_QUOTA_<TIER>_<FEATURE>`. Higher-tier limits cannot fall below lower-tier limits. UTC midnight resets allowances (05:30 India time). Counts are admitted attempts, including provider failures. The old usage database is preserved; historical deployment-wide counters are not assigned to invented user identities.
- New accounting is in `.veyra-runtime/accounts.sqlite3`, or `VEYRA_ACCOUNT_USAGE_DB`. Compose persists this in the existing `studio_usage` volume. Never delete that volume to recover disk space.
- Named Gemini/OpenRouter adapters require an explicit enabled flag, key and model. There is no automatic model choice. Generic code/refinement/repair configuration remains supported.
- Every external provider call also requires nonzero `VEYRA_EXTERNAL_REQUESTS_PER_DAY`, `VEYRA_EXTERNAL_OUTPUT_TOKENS_PER_DAY` and `VEYRA_PROVIDER_<NORMALIZED_NAME>_REQUESTS_PER_DAY` budgets. Defaults are zero, even when a key exists. Output-token reservations use the configured maximum; they are conservative budgets, not reported billable consumption. A provider's actual returned usage is separate and may be unavailable.
- Granite is optional and disabled by default. It requires an operator-local OpenAI-compatible server at the configured `127.0.0.1` endpoint. No model is downloaded and no Android device is used as a public endpoint. The current Docker composition does not provision a model sidecar.
- Browser drafts/history are scoped to provisioned accounts on the same origin. Existing operator drafts retain their old keys. Local browser storage is not encrypted; download a backup and use Data preferences on shared devices.

## Recovery

All prior branches and history remain. The installer prints the previous commit and creates `recovery/mission10-<old-sha>`. Switch back only after preserving any edits made after installation. Runtime databases and `.env` remain separate from Git; switching source versions does not restore or delete their contents.

The package also includes a full source snapshot for review. It contains no dependencies, models, runtime databases or credentials. The Git bundle is the preferred incremental installation path.
