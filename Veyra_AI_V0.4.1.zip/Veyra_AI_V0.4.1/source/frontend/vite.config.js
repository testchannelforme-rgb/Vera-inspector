import {defineConfig} from 'vite';
export default defineConfig({server:{allowedHosts:['terminal.local'],proxy:{'/api':{target:'http://127.0.0.1:8001',changeOrigin:false}}}});
